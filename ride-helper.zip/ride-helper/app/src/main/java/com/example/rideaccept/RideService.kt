package com.example.rideaccept

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideService : AccessibilityService() {
  private val labels = listOf("Accept", "ACCEPT", "Accept Ride", "Accept Booking")
  private var last = 0L

  override fun onAccessibilityEvent(e: AccessibilityEvent?) {
    val prefs = getSharedPreferences("p", MODE_PRIVATE)
    if (!prefs.getBoolean("on", false)) return
    val now = System.currentTimeMillis()
    if (now - last < 400) return
    val root = rootInActiveWindow ?: return
    for (t in labels) {
      for (n in root.findAccessibilityNodeInfosByText(t)) {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
          last = now
          return
        }
      }
    }
  }

  override fun onInterrupt() {}
}
